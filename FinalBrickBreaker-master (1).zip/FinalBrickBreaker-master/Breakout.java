//patrick and sean
//this class runs the game

public class Breakout{

   public static void main(String[] args){
      Game game = new Game();
   }

}