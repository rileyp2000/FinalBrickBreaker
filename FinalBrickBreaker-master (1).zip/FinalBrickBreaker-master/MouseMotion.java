//Patrick Riley and Sean Gibbons
//5/23/17
//This class was adapted from the java API listed here:
//http://docs.oracle.com/javase/tutorial/displayCode.html?code=http://docs.oracle.com/javase/tutorial/uiswing/examples/events/MouseMotionEventDemoProject/src/events/MouseMotionEventDemo.java

import java.awt.event.MouseMotionListener;
import java.awt.event.*;

public class MouseMotion implements MouseMotionListener{
      public void mouseDragged(MouseEvent e){ }
      
      public void mouseMoved(MouseEvent e){
            e.getX();
            
      }
      
}