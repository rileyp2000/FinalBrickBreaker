/**
*Patrick and Sean
*5/20/17
*This class is for all moving objects in the game
*
*
*/

import javax.swing.*;
import java.awt.*;

public interface MovingObject{

public void move(Velocity v);



}